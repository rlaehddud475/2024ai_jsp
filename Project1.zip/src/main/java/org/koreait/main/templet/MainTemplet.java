package org.koreait.main.templet;

public class MainTemplet {
}
