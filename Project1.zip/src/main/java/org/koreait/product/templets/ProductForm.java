package org.koreait.product.templets;

public class ProductForm {
}
