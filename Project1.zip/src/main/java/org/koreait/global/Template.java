package org.koreait.global;

public class Template {
}
